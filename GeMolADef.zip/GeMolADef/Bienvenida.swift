//
//  Bienvenida.swift
//  GeMolApop
//
//  Created by BRA on 22/10/18.
//  Copyright © 2018 BouCo. All rights reserved.
//

import UIKit

class Bienvenida: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
}
