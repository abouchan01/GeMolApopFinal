//
//  Vista1.swift
//  GeMolApop
//
//  Created by Bouchan on 19/10/18.
//  Copyright © 2018 BouCo. All rights reserved.
//

import UIKit

class Vista1: UIViewController {
    
    @IBAction func Boton(_ sender: UIButton) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
